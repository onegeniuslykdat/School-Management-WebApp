﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolApp.Controllers
{
    public class HomeController : Controller
    {
        public static List<string> subs = new List<string> { "Sub 1", "Sub 2" };
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View("Index");
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View("Index");
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(FormCollection form)
        {
            //ViewBag.Msg = "";
            foreach(string sb in subs)
            {
                ViewBag.Msg += form[sb];
            }
            return View();
        }
    }
}