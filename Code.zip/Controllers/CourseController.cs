﻿using SchoolApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolApp.Controllers
{
    public class CourseController : Controller
    {
        SchoolAppEntities SchoolAppEntities = new SchoolAppEntities();
        public static int courseId;
        // GET: Course
        public ActionResult Index()
        {
            return View();//RedirectToAction("AllCourses", "Student");
        }

        // GET: Course/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Course/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Course/Create
        [HttpPost]
        public ActionResult Create(FormCollection form)
        {
            try
            {
                // TODO: Add insert logic here
                Course course = new Course(form["CourseTitle"], form["CourseDescription"], form["CourseCode"], int.Parse(TeacherController.id));

                SchoolAppEntities.Courses.Add(course);
                SchoolAppEntities.SaveChanges();

                return RedirectToAction("Details", "Teacher", new { id = int.Parse(TeacherController.id)});
            }
            catch
            {
                return View();
            }
        }

        // GET: Course/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Course/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Course/Delete/5
        public ActionResult Delete(int sid)
        {
            Course course = SchoolAppEntities.Courses.Where(c => c.CourseID == sid).First();
            return View(course);
        }

        // POST: Course/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                Course course = SchoolAppEntities.Courses.Where(c => c.CourseID == id).First();
                SchoolAppEntities.Courses.Remove(course);
                Debug.WriteLine(SchoolAppEntities.SaveChanges());

                return RedirectToAction("Details", "Teacher", new { id = TeacherController.id});
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View();
            }
        }
    }
}
