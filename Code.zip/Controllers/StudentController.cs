﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SchoolApp.Controllers;
using SchoolApp.Models;

namespace SchoolApp.Views
{
    public class StudentController : Controller
    {
        SchoolAppEntities schoolAppEntities = new SchoolAppEntities();
        public static string email, id, name;

        public ActionResult AllCourses()
        {
            try
            {
                IEnumerable<Course> courses = schoolAppEntities.Courses;
                return View(courses);
            }
            catch(Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }
        [HttpPost]
        public ActionResult AllCourses(FormCollection checks)
        {
            try
            {
                // TODO: Add insert logic here

                Student student = schoolAppEntities.Students.Where(st => st.StudentID.ToString() == id).First();
                string selected = "";
                IEnumerable<Course> courses = schoolAppEntities.Courses.ToArray();
                //int n = 0;
                foreach(var co in courses)
                {
                    
                    selected += checks[co.CourseTitle] + ',';
                }

                student.StudentCourses = selected;
                
                Debug.WriteLine(selected);
                
                UpdateModel(student);
                schoolAppEntities.SaveChanges();

                return RedirectToAction("MyCourses", "Student");
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }

        public ActionResult MyCourses()
        {
            try
            {
                Student student = schoolAppEntities.Students.Where(st => st.StudentID.ToString() == id).First();

                return View(student.GetStudentCourses(student));
            }
            catch (NullReferenceException)
            {
                ViewBag.Error = "No courses registered yet";
                return View("Error");
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }

        public ActionResult Logout()
        {
            email = ""; name = ""; id = "0";
            return RedirectToAction("Index");
        }

        // GET: Student
        public ActionResult Index()
        {
            try
            {
                Student student = new Student();

                if (!student.AuthorizePage(email, int.Parse(id)))
                {
                    return View();
                }
                else
                {
                    return RedirectToAction("Details", new { id = int.Parse(id) });
                }
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }
        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            try
            {
                Student student = new Student();
                student = (Student)student.Get(form["StudentEmail"], student.EncodedPassword(form["SPw"]), schoolAppEntities);

                email = student.StudentEmail;
                id = student.StudentID.ToString();

                return RedirectToAction("Details", new { id = int.Parse(id) });
            }
            catch (Exception)
            {
                ViewBag.Error = "Invalid details";
                return View("Error");
            }
        }

        // GET: Student/Details/5
        [HandleError(Master = "Error")]
        public ActionResult Details(int id)
        {
            Student student = schoolAppEntities.Students.Where(st => st.StudentID == id).First();
            return View(student);
        }

        // GET: Student/Create
        public ActionResult Create()
        {
            email = ""; name = ""; id = "0";
            return View();
        }

        // POST: Student/Create
        [HttpPost]
        public ActionResult Create(FormCollection form)
        {
            try
            {
                // TODO: Add insert logic here

                Student student = new Student(form["StudentName"], form["StudentPhone"], form["StudentEmail"].ToLower(), (form["SPw"]), form["StudentClass"]);
                schoolAppEntities.Students.Add(student);
                schoolAppEntities.SaveChanges();

                id = student.StudentID.ToString();
                email = student.StudentEmail;
                name = student.StudentName;

                return RedirectToAction("Details", new { id = int.Parse(id) });
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }

        // GET: Student/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Student/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Student/Delete/5
        public ActionResult Delete()
        {
            Student student = schoolAppEntities.Students.Where(s => s.StudentID.ToString() == id).First();
            return View(student);
        }

        // POST: Student/Delete/5
        [HttpPost]
        public ActionResult Delete(FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                Student student = schoolAppEntities.Students.Where(s => s.StudentID.ToString() == id).First();
                schoolAppEntities.Students.Remove(student);
                schoolAppEntities.SaveChanges();

                return RedirectToAction("Index");
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }
    }
}
