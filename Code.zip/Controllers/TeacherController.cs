﻿using SchoolApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolApp.Controllers
{
    public class TeacherController : Controller
    {
        SchoolAppEntities schoolAppEntities = new SchoolAppEntities();
        public static string email, id, name;

        public ActionResult MyCourses()
        {
            Teacher teacher = schoolAppEntities.Teachers.Where(t => t.TeacherID.ToString() == id).First();
            return View(teacher.GetAllTeacherCourses(teacher));
        }
        public ActionResult MyStdHub()
        {
            return RedirectToAction("MyStudents", new { treeid = ViewBag.ID });
        }
        public ActionResult MyStudents(int cid)
        {
            //treeid = ViewBag.ID;
            Teacher teacher = schoolAppEntities.Teachers.Where(t => t.TeacherID.ToString() == id).First();

            Course course = schoolAppEntities.Courses.Where(c => c.CourseID == cid).First();
            CourseController.courseId = course.CourseID;

            return View(teacher.GetTeacherStudents(course));
        }

        public ActionResult Logout()
        {
            email = ""; name = ""; id = "0";
            return RedirectToAction("Index");
        }

        // GET: Teacher
        public ActionResult Index()
        {
            try
            {
                Teacher teacher = new Teacher();
                
                if (!teacher.AuthorizePage(email, int.Parse(id)))
                {
                    return View();
                }
                else
                {
                    return RedirectToAction("Details", new { id = int.Parse(id) });
                }
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }
        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            try
            {
                Teacher teacher = new Teacher();
                teacher = (Teacher)teacher.Get(form["TeacherEmail"], teacher.EncodedPassword(form["TPw"]), schoolAppEntities);

                email = teacher.TeacherEmail;
                id = teacher.TeacherID.ToString();
                
                return RedirectToAction("Details", new { id = int.Parse(id) });
            }
            catch (Exception)
            {
                ViewBag.Error = "Invalid details";
                return View("Error");
            }
           
        }

        // GET: Teacher/Details/5
        public ActionResult Details(int id)
        {
            Teacher teacher = schoolAppEntities.Teachers.Where(t => t.TeacherID == id).First();
            return View(teacher);
        }

        // GET: Teacher/Create
        public ActionResult Create()
        {
            email = ""; name = ""; id = "0";
            return View();
        }

        // POST: Teacher/Create
        [HttpPost]
        public ActionResult Create(FormCollection form)
        {
            try
            {
                // TODO: Add insert logic here
                
                Teacher teacher = new Teacher(form["TeacherName"], form["TeacherPhone"], form["TeacherEmail"].ToLower(), (form["TPw"]));
                schoolAppEntities.Teachers.Add(teacher);
                schoolAppEntities.SaveChanges();

                id = teacher.TeacherID.ToString();
                email = teacher.TeacherEmail;
                name = teacher.TeacherName;

                return RedirectToAction("Details", new { id = int.Parse(id) });
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message;
                return View("Error");
            }
        }

        // GET: Teacher/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Teacher/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Teacher/Delete/5
        public ActionResult Delete()
        {
            Teacher teacher = schoolAppEntities.Teachers.Where(t => t.TeacherID.ToString() == id).First();
            return View(teacher);
        }

        // POST: Teacher/Delete/5
        [HttpPost]
        public ActionResult Delete(FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                Teacher teacher = schoolAppEntities.Teachers.Where(t => t.TeacherID.ToString() == id).First();
                schoolAppEntities.Teachers.Remove(teacher);
                schoolAppEntities.SaveChanges();

                return RedirectToAction("Index");
            }
            catch (Exception E)
            {
                ViewBag.Error = E.Message; 
                return View();
            }
        }
    }
}
