﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace SchoolApp.Models
{
    public interface IPerson
    {

    }
    public abstract class Services
    {
        //public abstract bool UserLogin(string email, string password, SchoolAppEntities schoolAppEntities);
        //{
        //    return lists.Contains(email) && lists.Contains(EncodedPassword(password));
        //}

        public string EncodedPassword(string password)
        {
            ASCIIEncoding encoder = new ASCIIEncoding();
            
            var pwhash = SHA256.Create().ComputeHash(encoder.GetBytes(password));
            StringBuilder code = new StringBuilder();
            foreach (var p in pwhash)
            {
                code.Append(p);
            }
            return code.ToString().Substring(0, 63);
        }

        //object, dynamic, IPerson... Find a student or teacher
        public abstract IPerson Get(string email, string encPassword, SchoolAppEntities schoolAppEntities);

        // Get a course that is taught by a teacher
        //public /*IEnumerable<*/Course GetTeacherCourse(Teacher teacher)
        //{
        //    SchoolAppEntities schoolAppEntities = new SchoolAppEntities();
        //    return schoolAppEntities.Courses.Where(c => c.CourseTeacher == teacher.TeacherID).First();
        //}

        // Get courses taught by a teacher
        public IEnumerable<Course> GetAllTeacherCourses(Teacher teacher)
        {
            SchoolAppEntities schoolAppEntities = new SchoolAppEntities();
            return schoolAppEntities.Courses.Where(c => c.CourseTeacher == teacher.TeacherID);
        }

        // Get students who are taking a teacher's course... Should be combined with GetAllTeacherCourses
        public IEnumerable<Student> GetTeacherStudents(Course course)
        {
            SchoolAppEntities schoolAppEntities = new SchoolAppEntities();
            List<Student> students = schoolAppEntities.Students.ToList();
            //IEnumerable<Course> courses = teacher.GetAllTeacherCourses(teacher);

            foreach (Student std in students)
            {
                if(std.StudentCourses.Split(',').Contains(course.CourseID.ToString()))
                {
                    students.Add(std);
                }
            }

            return students;//schoolAppEntities.Students.Where(st => st.StudentCourses.Split(',').ToList().Contains(course.CourseID.ToString()));
        }

        // Get courses taken by a student
        public IEnumerable<Course> GetStudentCourses(Student student)
        {
            SchoolAppEntities schoolAppEntities = new SchoolAppEntities();

            List<string> courseids = new List<string> { };
            
            foreach (var c in student.StudentCourses.Split(','))
            {
                if (c != "")
                {
                    courseids.Add(c);
                }
            }
            List<Course> courses = new List<Course>();

            foreach(string id in courseids)
            {
                courses.Add(schoolAppEntities.Courses.Where(cou => cou.CourseID.ToString() == id).First());
            }
            return courses;
        }

        public abstract bool AuthorizePage(string email, int id);
    }
}